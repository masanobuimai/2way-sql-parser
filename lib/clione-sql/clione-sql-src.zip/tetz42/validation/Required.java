package tetz42.validation;

public enum Required {
	FALSE, NOT_NULL, NOT_EMPTY
}
