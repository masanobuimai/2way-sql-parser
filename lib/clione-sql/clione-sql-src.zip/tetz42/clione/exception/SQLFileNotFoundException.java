package tetz42.clione.exception;

public class SQLFileNotFoundException extends RuntimeException {
    /**
     *
     */
    private static final long serialVersionUID = 1579277560575392020L;

    public SQLFileNotFoundException(String msg) {
        super(msg);
    }

    public SQLFileNotFoundException(String msg, Throwable t) {
        super(msg, t);
    }
}
