/*
 * Copyright 2011 tetsuo.ohta[at]gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package tetz42.clione.gen;

import tetz42.clione.lang.Instruction;
import tetz42.clione.node.SQLNode;
import tetz42.clione.util.ParamMap;

import java.util.List;
import java.util.Map;

import static tetz42.clione.lang.ContextUtil.*;
import static tetz42.clione.util.ClioneUtil.*;

public class SQLGenerator {

    public String sql;
    public List<Object> params;
    public boolean isSqlOutputed = false;
    private Object[] negativeValues;

    public SQLGenerator() {
        this(null);
    }

    public SQLGenerator(Object[] negativeValues) {
        this.negativeValues = negativeValues;
    }

    public SQLGenerator negativeValues(Object... negativeValues) {
        this.negativeValues = negativeValues;
        return this;
    }

    public SQLGenerator appendNegativeValues(Object... negativeValues) {
        this.negativeValues = join(this.negativeValues, negativeValues);
        return this;
    }

    public String genSql(Map<String, Object> map, SQLNode sqlNode) {
        pushResouceInfo(sqlNode.resourceInfo);
        addNegative(negativeValues);
        try {
            ParamMap paramMap;
            if (map == null)
                paramMap = new ParamMap();
            else if (map instanceof ParamMap) {
                paramMap = (ParamMap) map;
            }
            else {
                paramMap = new ParamMap();
                paramMap.putAll(map);
            }

            Instruction inst = sqlNode.perform(paramMap);
            this.params = inst.params;
            return this.sql = inst.replacement;
        }
        finally {
            popResourceInfo();
            clearNegative();
        }
    }
}
