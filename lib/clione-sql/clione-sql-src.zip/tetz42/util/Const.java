package tetz42.util;

public interface Const {
    public static final String CRLF = System.getProperty("line.separator");

}
