package tetz42.util;

public interface Function<RESULT> {
    RESULT apply();
}
