package tetz42.cellom;

public interface IHeader {
	Iterable<Iterable<ICell>> each();
}
