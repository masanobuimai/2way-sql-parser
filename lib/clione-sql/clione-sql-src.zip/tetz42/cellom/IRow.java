package tetz42.cellom;

public interface IRow {

	Iterable<ICell> each();

}
